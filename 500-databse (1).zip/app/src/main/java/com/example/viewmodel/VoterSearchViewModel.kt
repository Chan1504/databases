package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.VoterRepository
import com.example.model.VoterRecord
import com.example.util.AppLanguage
import com.example.util.LocaleStrings
import com.example.util.PdfSlipUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class AppUiState(
    // Authentication State
    val isLoggedIn: Boolean = false,
    val loginError: String? = null,
    val usernameInput: String = "",
    val passwordInput: String = "",
    val isPasswordVisible: Boolean = false,

    // Navigation State: "home" | "search" | "details" | "slip" | "settings"
    val currentTab: String = "home",

    // Language State
    val selectedLanguage: AppLanguage = AppLanguage.ENGLISH,

    // Dataset & Search
    val allRecords: List<VoterRecord> = emptyList(),
    val filteredRecords: List<VoterRecord> = emptyList(),
    val isLoading: Boolean = true,
    val nameQuery: String = "",
    val partQuery: String = "",
    val wardQuery: String = "",
    val totalRecords: Int = 0,
    val totalParts: Int = 0,
    val totalWards: Int = 0,

    // Validation / Search Errors
    val partError: String? = null,
    val wardError: String? = null,

    // Selected Person for Details & Slip
    val selectedPerson: VoterRecord? = null,

    // Feedback
    val snackbarMessage: String? = null,
    val lastDownloadedPdf: File? = null
)

class VoterSearchViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = VoterRepository(application.applicationContext)

    // Configurable Single Staff Credentials
    private val staffUsername = "staff"
    private val staffPassword = "password123"

    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null

    init {
        initializeDatabase()
    }

    private fun initializeDatabase() {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(isLoading = true)
            }
            try {
                val records = repository.initializeIfEmpty()
                val (total, parts, wards) = repository.getCounts()

                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        allRecords = records,
                        filteredRecords = records,
                        totalRecords = total,
                        totalParts = parts,
                        totalWards = wards,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        snackbarMessage = "Database error: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    // --- Authentication ---
    fun onUsernameChange(input: String) {
        _uiState.value = _uiState.value.copy(usernameInput = input, loginError = null)
    }

    fun onPasswordChange(input: String) {
        _uiState.value = _uiState.value.copy(passwordInput = input, loginError = null)
    }

    fun togglePasswordVisibility() {
        _uiState.value = _uiState.value.copy(isPasswordVisible = !_uiState.value.isPasswordVisible)
    }

    fun login() {
        val u = _uiState.value.usernameInput.trim()
        val p = _uiState.value.passwordInput
        val lang = _uiState.value.selectedLanguage

        if (u == staffUsername && p == staffPassword) {
            _uiState.value = _uiState.value.copy(
                isLoggedIn = true,
                loginError = null,
                currentTab = "home"
            )
        } else {
            _uiState.value = _uiState.value.copy(
                loginError = LocaleStrings.invalidCredentials(lang)
            )
        }
    }

    fun logout() {
        _uiState.value = _uiState.value.copy(
            isLoggedIn = false,
            usernameInput = "",
            passwordInput = "",
            loginError = null,
            selectedPerson = null,
            currentTab = "home"
        )
    }

    // --- Navigation ---
    fun selectTab(tab: String) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun setLanguage(language: AppLanguage) {
        _uiState.value = _uiState.value.copy(selectedLanguage = language)
    }

    // --- Search & Filtering via Room Database ---
    fun onNameQueryChange(query: String) {
        _uiState.value = _uiState.value.copy(nameQuery = query)
        scheduleSearch(debounceMs = 150L)
    }

    fun onPartQueryChange(query: String) {
        val lang = _uiState.value.selectedLanguage
        val partNum = query.trim().toIntOrNull()
        val error = if (query.isNotBlank() && (partNum == null || partNum !in 1..250)) {
            LocaleStrings.invalidPartNumber(lang)
        } else {
            null
        }

        _uiState.value = _uiState.value.copy(partQuery = query, partError = error)
        scheduleSearch(debounceMs = 100L)
    }

    fun onWardQueryChange(query: String) {
        val lang = _uiState.value.selectedLanguage
        val wardNum = query.trim().toIntOrNull()
        val error = if (query.isNotBlank() && (wardNum == null || wardNum !in 1..50)) {
            LocaleStrings.invalidWardNumber(lang)
        } else {
            null
        }

        _uiState.value = _uiState.value.copy(wardQuery = query, wardError = error)
        scheduleSearch(debounceMs = 100L)
    }

    fun clearFilters() {
        searchJob?.cancel()
        _uiState.value = _uiState.value.copy(
            nameQuery = "",
            partQuery = "",
            wardQuery = "",
            partError = null,
            wardError = null,
            filteredRecords = _uiState.value.allRecords
        )
    }

    private fun scheduleSearch(debounceMs: Long) {
        searchJob?.cancel()

        val name = _uiState.value.nameQuery.trim()
        val partStr = _uiState.value.partQuery.trim()
        val wardStr = _uiState.value.wardQuery.trim()

        // If all search fields are cleared, restore instantly with zero delay
        if (name.isEmpty() && partStr.isEmpty() && wardStr.isEmpty()) {
            _uiState.value = _uiState.value.copy(filteredRecords = _uiState.value.allRecords)
            return
        }

        searchJob = viewModelScope.launch(Dispatchers.IO) {
            if (debounceMs > 0) {
                delay(debounceMs)
            }

            val partInt = partStr.toIntOrNull()
            val wardInt = wardStr.toIntOrNull()

            try {
                // High performance indexed SQLite query
                val results = repository.searchRecords(
                    nameQuery = name,
                    partNo = partInt,
                    wardNumber = wardInt
                )
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(filteredRecords = results)
                }
            } catch (e: Exception) {
                // Fast in-memory fallback
                val all = _uiState.value.allRecords
                val filtered = withContext(Dispatchers.Default) {
                    all.filter { r ->
                        val matchName = name.isEmpty() || r.name.contains(name, ignoreCase = true)
                        val matchPart = partInt == null || r.partNo == partInt
                        val matchWard = wardInt == null || r.wardNumber == wardInt
                        matchName && matchPart && matchWard
                    }
                }
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(filteredRecords = filtered)
                }
            }
        }
    }

    // --- Person Details & Slip Actions ---
    fun selectPersonForDetails(record: VoterRecord) {
        _uiState.value = _uiState.value.copy(selectedPerson = record, currentTab = "details")
    }

    fun openSlip(record: VoterRecord) {
        _uiState.value = _uiState.value.copy(selectedPerson = record, currentTab = "slip")
    }

    fun navigateBackFromDetails() {
        _uiState.value = _uiState.value.copy(currentTab = "search")
    }

    fun navigateBackFromSlip() {
        _uiState.value = _uiState.value.copy(currentTab = "details")
    }

    fun printSlip(context: Context, record: VoterRecord) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = PdfSlipUtil.printVoterSlip(context, record)
            if (!success) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        snackbarMessage = "Printer service not available on this device. You can Download or Share the PDF instead."
                    )
                }
            }
        }
    }

    fun downloadPdf(context: Context, record: VoterRecord) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = PdfSlipUtil.downloadAndOpenPdf(context, record)
            withContext(Dispatchers.Main) {
                if (file != null) {
                    _uiState.value = _uiState.value.copy(
                        lastDownloadedPdf = file,
                        snackbarMessage = "PDF saved: ${file.name}"
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        snackbarMessage = "Error generating PDF. Please try again."
                    )
                }
            }
        }
    }

    fun sharePdf(context: Context, record: VoterRecord) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = PdfSlipUtil.sharePdf(context, record)
            if (!success) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        snackbarMessage = "No application available to share PDF, or error preparing share."
                    )
                }
            }
        }
    }

    fun clearSnackbar() {
        _uiState.value = _uiState.value.copy(snackbarMessage = null)
    }
}

