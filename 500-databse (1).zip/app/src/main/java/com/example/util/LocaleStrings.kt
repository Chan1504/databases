package com.example.util

/**
 * Supported UI languages: English, Hindi, Marathi.
 */
enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "हिन्दी (Hindi)"),
    MARATHI("mr", "मराठी (Marathi)")
}

/**
 * Localization dictionary covering all UI labels and messages across English, Hindi, and Marathi.
 * The dataset's actual names and addresses are not translated.
 */
object LocaleStrings {

    fun appTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Person Search"
        AppLanguage.HINDI -> "व्यक्ति खोज (Person Search)"
        AppLanguage.MARATHI -> "व्यक्ती शोध (Person Search)"
    }

    fun login(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Login"
        AppLanguage.HINDI -> "लॉग इन"
        AppLanguage.MARATHI -> "लॉग इन"
    }

    fun logout(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Logout"
        AppLanguage.HINDI -> "लॉग आउट"
        AppLanguage.MARATHI -> "लॉग आउट"
    }

    fun staffLoginTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Staff / Volunteer Login"
        AppLanguage.HINDI -> "कर्मचारी / स्वयंसेवक लॉगिन"
        AppLanguage.MARATHI -> "कर्मचारी / स्वयंसेवक लॉगिन"
    }

    fun staffLoginSubtitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Enter your staff credentials to access voter records"
        AppLanguage.HINDI -> "मतदाता रिकॉर्ड देखने के लिए अपने क्रेडेंशियल दर्ज करें"
        AppLanguage.MARATHI -> "मतदार नोंदी पाहण्यासाठी आपले क्रेडेन्शियल्स प्रविष्ट करा"
    }

    fun username(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Username"
        AppLanguage.HINDI -> "उपयोगकर्ता नाम"
        AppLanguage.MARATHI -> "वापरकर्ता नाव"
    }

    fun password(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Password"
        AppLanguage.HINDI -> "पासवर्ड"
        AppLanguage.MARATHI -> "पासवर्ड"
    }

    fun invalidCredentials(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Invalid username or password. Please try again."
        AppLanguage.HINDI -> "अमान्य उपयोगकर्ता नाम या पासवर्ड। कृपया पुनः प्रयास करें।"
        AppLanguage.MARATHI -> "अवैध वापरकर्ता नाव किंवा पासवर्ड. कृपया पुन्हा प्रयत्न करा."
    }

    fun searchPerson(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Search Person"
        AppLanguage.HINDI -> "व्यक्ति खोजें"
        AppLanguage.MARATHI -> "व्यक्ती शोधा"
    }

    fun searchByName(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Search by Name (Full / Partial)"
        AppLanguage.HINDI -> "नाम से खोजें (पूर्ण या आंशिक)"
        AppLanguage.MARATHI -> "नावाने शोधा (पूर्ण किंवा आंशिक)"
    }

    fun searchByPartNo(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Search by Part No."
        AppLanguage.HINDI -> "भाग संख्या द्वारा खोजें"
        AppLanguage.MARATHI -> "भाग क्रमांकाद्वारे शोधा"
    }

    fun searchByWardNo(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Search by Ward Number"
        AppLanguage.HINDI -> "वार्ड संख्या द्वारा खोजें"
        AppLanguage.MARATHI -> "वॉर्ड क्रमांकाद्वारे शोधा"
    }

    fun partNoHint(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Part No. (1–250)"
        AppLanguage.HINDI -> "भाग संख्या (1–250)"
        AppLanguage.MARATHI -> "भाग क्रमांक (1–250)"
    }

    fun wardNoHint(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Ward No. (1–50)"
        AppLanguage.HINDI -> "वार्ड संख्या (1–50)"
        AppLanguage.MARATHI -> "वॉर्ड क्रमांक (1–50)"
    }

    fun clearFilters(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Clear Filters"
        AppLanguage.HINDI -> "फ़िल्टर हटाएं"
        AppLanguage.MARATHI -> "फिल्टर साफ करा"
    }

    fun name(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Name"
        AppLanguage.HINDI -> "नाम"
        AppLanguage.MARATHI -> "नाव"
    }

    fun address(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Address"
        AppLanguage.HINDI -> "पता"
        AppLanguage.MARATHI -> "पत्ता"
    }

    fun partNo(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Part No."
        AppLanguage.HINDI -> "भाग संख्या"
        AppLanguage.MARATHI -> "भाग क्रमांक"
    }

    fun wardNumber(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Ward Number"
        AppLanguage.HINDI -> "वार्ड संख्या"
        AppLanguage.MARATHI -> "वॉर्ड क्रमांक"
    }

    fun srNo(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Sr. No."
        AppLanguage.HINDI -> "क्र. सं."
        AppLanguage.MARATHI -> "अनु. क्र."
    }

    fun viewDetails(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "View Details"
        AppLanguage.HINDI -> "विवरण देखें"
        AppLanguage.MARATHI -> "तपशील पहा"
    }

    fun generateSlip(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Generate Slip"
        AppLanguage.HINDI -> "पर्ची बनाएं"
        AppLanguage.MARATHI -> "पावती तयार करा"
    }

    fun print(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Print"
        AppLanguage.HINDI -> "प्रिंट"
        AppLanguage.MARATHI -> "प्रिंट"
    }

    fun printSlip(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Print Slip"
        AppLanguage.HINDI -> "पर्ची प्रिंट करें"
        AppLanguage.MARATHI -> "पावती प्रिंट करा"
    }

    fun downloadPdf(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Download PDF"
        AppLanguage.HINDI -> "पीडीएफ डाउनलोड करें"
        AppLanguage.MARATHI -> "पीडीएफ डाउनलोड करा"
    }

    fun share(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Share"
        AppLanguage.HINDI -> "शेयर करें"
        AppLanguage.MARATHI -> "शेअर करा"
    }

    fun sharePdf(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Share PDF"
        AppLanguage.HINDI -> "पीडीएफ शेयर करें"
        AppLanguage.MARATHI -> "पीडीएफ शेअर करा"
    }

    fun resultsFound(count: Int, lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "$count results found"
        AppLanguage.HINDI -> "$count परिणाम मिले"
        AppLanguage.MARATHI -> "$count निकाल सापडले"
    }

    fun noResultsFound(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "No person found matching your search."
        AppLanguage.HINDI -> "आपकी खोज से मेल खाने वाला कोई व्यक्ति नहीं मिला।"
        AppLanguage.MARATHI -> "आपल्या शोधाशी जुळणारी कोणतीही व्यक्ती आढळली नाही."
    }

    fun invalidPartNumber(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Please enter a Part Number between 1 and 250."
        AppLanguage.HINDI -> "कृपया 1 और 250 के बीच भाग संख्या दर्ज करें।"
        AppLanguage.MARATHI -> "कृपया 1 ते 250 मधील भाग क्रमांक प्रविष्ट करा."
    }

    fun invalidWardNumber(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Please select a Ward Number between 1 and 50."
        AppLanguage.HINDI -> "कृपया 1 और 50 के बीच वार्ड संख्या चुनें।"
        AppLanguage.MARATHI -> "कृपया 1 ते 50 मधील वॉर्ड क्रमांक निवडा."
    }

    fun personDetailsTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Person Details"
        AppLanguage.HINDI -> "व्यक्ति विवरण"
        AppLanguage.MARATHI -> "व्यक्ती तपशील"
    }

    fun personSlipTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "PERSON SLIP"
        AppLanguage.HINDI -> "व्यक्ति पर्ची (PERSON SLIP)"
        AppLanguage.MARATHI -> "व्यक्ती पावती (PERSON SLIP)"
    }

    fun totalRecords(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Total Records"
        AppLanguage.HINDI -> "कुल रिकॉर्ड्स"
        AppLanguage.MARATHI -> "एकूण नोंदी"
    }

    fun totalParts(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Total Part Numbers"
        AppLanguage.HINDI -> "कुल भाग संख्याएँ"
        AppLanguage.MARATHI -> "एकूण भाग क्रमांक"
    }

    fun totalWards(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Total Wards"
        AppLanguage.HINDI -> "कुल वार्ड"
        AppLanguage.MARATHI -> "एकूण वॉर्ड"
    }

    fun navHome(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Home"
        AppLanguage.HINDI -> "होम"
        AppLanguage.MARATHI -> "मुख्यपृष्ठ"
    }

    fun navSearch(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Search"
        AppLanguage.HINDI -> "खोजें"
        AppLanguage.MARATHI -> "शोध"
    }

    fun navSettings(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Settings"
        AppLanguage.HINDI -> "सेटिंग्स"
        AppLanguage.MARATHI -> "सेटिंग्ज"
    }

    fun languageSelector(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Language / भाषा / भाषा"
        AppLanguage.HINDI -> "भाषा (Language)"
        AppLanguage.MARATHI -> "भाषा (Language)"
    }

    fun appInformation(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "App Information"
        AppLanguage.HINDI -> "ऐप जानकारी"
        AppLanguage.MARATHI -> "ॲप माहिती"
    }

    fun offlineReady(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Offline Ready • Local SQLite/Room Database"
        AppLanguage.HINDI -> "ऑफ़लाइन तैयार • स्थानीय SQLite/Room डेटाबेस"
        AppLanguage.MARATHI -> "ऑफलाइन तयार • स्थानिक SQLite/Room डेटाबेस"
    }

    fun close(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Close"
        AppLanguage.HINDI -> "बंद करें"
        AppLanguage.MARATHI -> "बंद करा"
    }

    fun back(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Back"
        AppLanguage.HINDI -> "वापस"
        AppLanguage.MARATHI -> "मागे"
    }
}
