package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.model.VoterRecord
import java.io.File
import java.io.FileOutputStream

object PdfSlipUtil {

    // Standard A4 dimensions in PostScript points (72 points per inch)
    const val A4_WIDTH = 595
    const val A4_HEIGHT = 842

    /**
     * Sanitizes filename for saving as PDF: Person_Slip_[Name].pdf
     */
    fun getSanitizedFileName(record: VoterRecord): String {
        val cleanName = record.name.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").trim('_')
        return "Person_Slip_${cleanName}.pdf"
    }

    /**
     * Draws the clean card-style person slip strictly according to User Specification:
     *
     * PERSON SLIP
     * Name: [Person Name]
     * Address: [Address]
     * Part No.: [Part Number]
     * Ward Number: [Ward Number]
     *
     * (Contains ONLY the selected person's info. No QR code, no barcode, no generated unique ID)
     */
    fun drawVoterSlipPage(canvas: Canvas, record: VoterRecord) {
        val width = A4_WIDTH.toFloat()
        val height = A4_HEIGHT.toFloat()

        // Background: Crisp white
        val bgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        // Card Container Dimensions on A4 page
        val cardMargin = 40f
        val cardWidth = width - (2 * cardMargin)
        val cardHeight = 360f
        val cardTop = 80f
        val cardRect = RectF(cardMargin, cardTop, cardMargin + cardWidth, cardTop + cardHeight)

        // Card background: subtle clean off-white
        val cardBgPaint = Paint().apply {
            color = Color.rgb(248, 250, 252) // Slate 50
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(cardRect, 12f, 12f, cardBgPaint)

        // Card Border
        val cardBorderPaint = Paint().apply {
            color = Color.rgb(30, 58, 138) // Civic Navy
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawRoundRect(cardRect, 12f, 12f, cardBorderPaint)

        // Header Banner inside Card
        val headerHeight = 60f
        val headerRect = RectF(cardMargin, cardTop, cardMargin + cardWidth, cardTop + headerHeight)
        val headerBgPaint = Paint().apply {
            color = Color.rgb(30, 58, 138) // Civic Navy
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        // Top corners rounded
        canvas.drawRoundRect(headerRect, 12f, 12f, headerBgPaint)
        canvas.drawRect(cardMargin, cardTop + 20f, cardMargin + cardWidth, cardTop + headerHeight, headerBgPaint)

        // Header Text: PERSON SLIP
        val headerTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 22f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
            letterSpacing = 0.08f
        }
        canvas.drawText("PERSON SLIP", width / 2f, cardTop + 38f, headerTextPaint)

        // Field Content Layout
        val leftX = cardMargin + 36f
        val valueX = cardMargin + 160f
        val contentWidth = cardWidth - 72f

        val labelPaint = Paint().apply {
            color = Color.rgb(71, 85, 105) // Slate 600
            textSize = 14f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            isAntiAlias = true
        }

        val valuePaint = Paint().apply {
            color = Color.rgb(15, 23, 42) // Slate 900
            textSize = 15f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            isAntiAlias = true
        }

        val normalValuePaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 14f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            isAntiAlias = true
        }

        val dividerPaint = Paint().apply {
            color = Color.rgb(226, 232, 240) // Slate 200
            strokeWidth = 1f
            isAntiAlias = true
        }

        var curY = cardTop + headerHeight + 45f

        // 1. Name
        canvas.drawText("Name", leftX, curY, labelPaint)
        canvas.drawText(record.name, valueX, curY, valuePaint)

        curY += 22f
        canvas.drawLine(leftX, curY, leftX + contentWidth, curY, dividerPaint)
        curY += 34f

        // 2. Address
        canvas.drawText("Address", leftX, curY, labelPaint)
        val addressText = record.address
        if (addressText.length > 38) {
            val commaIdx = addressText.lastIndexOf(',', 36).takeIf { it > 0 } ?: 34
            val line1 = addressText.substring(0, commaIdx + 1).trim()
            val line2 = addressText.substring(commaIdx + 1).trim()
            canvas.drawText(line1, valueX, curY, normalValuePaint)
            curY += 20f
            canvas.drawText(line2, valueX, curY, normalValuePaint)
        } else {
            canvas.drawText(addressText, valueX, curY, normalValuePaint)
        }

        curY += 22f
        canvas.drawLine(leftX, curY, leftX + contentWidth, curY, dividerPaint)
        curY += 34f

        // 3. Part No.
        canvas.drawText("Part No.", leftX, curY, labelPaint)
        canvas.drawText("${record.partNo}", valueX, curY, valuePaint)

        curY += 22f
        canvas.drawLine(leftX, curY, leftX + contentWidth, curY, dividerPaint)
        curY += 34f

        // 4. Ward Number
        canvas.drawText("Ward Number", leftX, curY, labelPaint)
        canvas.drawText("${record.wardNumber}", valueX, curY, valuePaint)

        // Footer inside page: clean minimal page note
        val footerPaint = Paint().apply {
            color = Color.rgb(148, 163, 184)
            textSize = 9f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("Official Person Slip • Generated for Staff & Volunteer Verification", width / 2f, cardTop + cardHeight + 40f, footerPaint)
    }

    /**
     * Generates and saves the PDF file named Person_Slip_[Name].pdf to app's external documents directory.
     * Returns the created File or null on error.
     */
    fun generatePdfFile(context: Context, record: VoterRecord): File? {
        return try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH, A4_HEIGHT, 1).create()
            val page = pdfDocument.startPage(pageInfo)

            drawVoterSlipPage(page.canvas, record)
            pdfDocument.finishPage(page)

            val docsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
            if (!docsDir.exists()) docsDir.mkdirs()

            val fileName = getSanitizedFileName(record)
            val outputFile = File(docsDir, fileName)

            FileOutputStream(outputFile).use { fos ->
                pdfDocument.writeTo(fos)
            }
            pdfDocument.close()
            outputFile
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Shares the generated PDF using Android's standard share intent chooser.
     */
    fun sharePdf(context: Context, record: VoterRecord): Boolean {
        val file = generatePdfFile(context, record) ?: return false
        return try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Person Slip - ${record.name}")
                putExtra(Intent.EXTRA_TEXT, "Person Slip for ${record.name} (Part No: ${record.partNo}, Ward No: ${record.wardNumber})")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "Share Person Slip PDF").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Downloads/saves the PDF and triggers viewing/opening.
     */
    fun downloadAndOpenPdf(context: Context, record: VoterRecord): File? {
        val file = generatePdfFile(context, record) ?: return null
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // PDF viewer not found; fallback to Toast notification of downloaded file path
            Toast.makeText(context, "Saved to ${file.name}", Toast.LENGTH_SHORT).show()
        }
        return file
    }

    /**
     * Prints ONLY the selected person's slip using Android PrintManager.
     * Conforms to A4 paper, hides navigation, search screen, and any other person's info.
     */
    fun printVoterSlip(context: Context, record: VoterRecord): Boolean {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            ?: return false

        val jobName = "Person_Slip_${record.name.replace(' ', '_')}"
        val printAdapter = object : PrintDocumentAdapter() {
            private var printedPdfDocument: PdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }

                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()

                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                if (destination == null) {
                    callback?.onWriteFailed("Destination descriptor is null")
                    return
                }

                printedPdfDocument = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH, A4_HEIGHT, 1).create()
                val page = printedPdfDocument?.startPage(pageInfo)

                if (page != null) {
                    drawVoterSlipPage(page.canvas, record)
                    printedPdfDocument?.finishPage(page)
                }

                try {
                    FileOutputStream(destination.fileDescriptor).use { output ->
                        printedPdfDocument?.writeTo(output)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    printedPdfDocument?.close()
                    printedPdfDocument = null
                }
            }
        }

        val printAttributes = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build()

        return try {
            printManager.print(jobName, printAdapter, printAttributes)
            true
        } catch (e: Exception) {
            false
        }
    }
}
