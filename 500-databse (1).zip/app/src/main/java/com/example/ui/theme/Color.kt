package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary deep navy civic tones
val CivicNavy90 = Color(0xFF0A192F)
val CivicNavy80 = Color(0xFF1E3A8A)
val CivicNavy60 = Color(0xFF2563EB)
val CivicNavy20 = Color(0xFFDBEAFE)
val CivicNavy10 = Color(0xFFEFF6FF)

// Accent Emerald tones
val EmeraldGreen80 = Color(0xFF065F46)
val EmeraldGreen60 = Color(0xFF059669)
val EmeraldGreen20 = Color(0xFFA7F3D0)
val EmeraldGreen10 = Color(0xFFECFDF5)

// Amber / Gold accents for badges
val AmberGold80 = Color(0xFF92400E)
val AmberGold60 = Color(0xFFD97706)
val AmberGold20 = Color(0xFFFDE68A)
val AmberGold10 = Color(0xFFFFFBEB)

// Neutral tones
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
val PureWhite = Color(0xFFFFFFFF)
