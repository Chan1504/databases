package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.DashboardSection
import com.example.ui.components.SearchPersonSection
import com.example.ui.components.SearchResultsSection
import com.example.ui.components.searchResultsItems
import com.example.util.LocaleStrings
import com.example.viewmodel.VoterSearchViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppNavigation(
    viewModel: VoterSearchViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    // If staff member is not logged in, show Login Screen (Requirement #3)
    if (!uiState.isLoggedIn) {
        LoginScreen(
            username = uiState.usernameInput,
            password = uiState.passwordInput,
            isPasswordVisible = uiState.isPasswordVisible,
            errorMessage = uiState.loginError,
            selectedLanguage = uiState.selectedLanguage,
            onUsernameChange = viewModel::onUsernameChange,
            onPasswordChange = viewModel::onPasswordChange,
            onTogglePasswordVisibility = viewModel::togglePasswordVisibility,
            onLanguageSelect = viewModel::setLanguage,
            onLoginClick = viewModel::login
        )
        return
    }

    // Person Details Screen (Requirement #5)
    if (uiState.currentTab == "details" && uiState.selectedPerson != null) {
        PersonDetailsScreen(
            record = uiState.selectedPerson!!,
            selectedLanguage = uiState.selectedLanguage,
            onBack = viewModel::navigateBackFromDetails,
            onGenerateSlip = { viewModel.openSlip(uiState.selectedPerson!!) }
        )
        return
    }

    // Person Slip Screen (Requirements #6, #7, #8, #9)
    if (uiState.currentTab == "slip" && uiState.selectedPerson != null) {
        PersonSlipScreen(
            record = uiState.selectedPerson!!,
            selectedLanguage = uiState.selectedLanguage,
            onBack = viewModel::navigateBackFromSlip,
            onPrint = { viewModel.printSlip(context, uiState.selectedPerson!!) },
            onDownloadPdf = { viewModel.downloadPdf(context, uiState.selectedPerson!!) },
            onSharePdf = { viewModel.sharePdf(context, uiState.selectedPerson!!) }
        )
        return
    }

    // Main Scaffold with Bottom Navigation (Home, Search, Settings)
    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("main_app_scaffold"),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(end = 10.dp)
                        ) {
                            Box(modifier = Modifier.padding(6.dp)) {
                                Icon(
                                    imageVector = Icons.Default.HowToVote,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = LocaleStrings.appTitle(uiState.selectedLanguage),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "500 Verified Records • Offline SQLite",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::logout, modifier = Modifier.testTag("action_logout")) {
                        Icon(
                            Icons.AutoMirrored.Filled.Logout,
                            contentDescription = LocaleStrings.logout(uiState.selectedLanguage)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = uiState.currentTab == "home",
                    onClick = { viewModel.selectTab("home") },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text(LocaleStrings.navHome(uiState.selectedLanguage)) },
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = uiState.currentTab == "search",
                    onClick = { viewModel.selectTab("search") },
                    icon = { Icon(Icons.Default.Search, contentDescription = null) },
                    label = { Text(LocaleStrings.navSearch(uiState.selectedLanguage)) },
                    modifier = Modifier.testTag("nav_search")
                )
                NavigationBarItem(
                    selected = uiState.currentTab == "settings",
                    onClick = { viewModel.selectTab("settings") },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text(LocaleStrings.navSettings(uiState.selectedLanguage)) },
                    modifier = Modifier.testTag("nav_settings")
                )
            }
        }
    ) { innerPadding ->
        when (uiState.currentTab) {
            "home" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .testTag("home_screen"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(16.dp)
                ) {
                    item(key = "dashboard") {
                        DashboardSection(
                            totalRecords = uiState.totalRecords,
                            totalPartNumbers = uiState.totalParts,
                            totalWards = uiState.totalWards,
                            selectedLanguage = uiState.selectedLanguage
                        )
                    }

                    item(key = "quick_search") {
                        SearchPersonSection(
                            nameQuery = uiState.nameQuery,
                            partQuery = uiState.partQuery,
                            wardQuery = uiState.wardQuery,
                            partError = uiState.partError,
                            wardError = uiState.wardError,
                            selectedLanguage = uiState.selectedLanguage,
                            onNameChange = viewModel::onNameQueryChange,
                            onPartChange = viewModel::onPartQueryChange,
                            onWardChange = viewModel::onWardQueryChange,
                            onClearFilters = viewModel::clearFilters,
                            activeMatchCount = uiState.filteredRecords.size
                        )
                    }

                    searchResultsItems(
                        records = uiState.filteredRecords,
                        isLoading = uiState.isLoading,
                        selectedLanguage = uiState.selectedLanguage,
                        onViewDetails = viewModel::selectPersonForDetails,
                        onViewSlip = viewModel::openSlip,
                        onPrint = { record -> viewModel.printSlip(context, record) },
                        onDownloadPdf = { record -> viewModel.downloadPdf(context, record) },
                        onSharePdf = { record -> viewModel.sharePdf(context, record) },
                        onClearFilters = viewModel::clearFilters
                    )
                }
            }

            "search" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .testTag("search_screen"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(16.dp)
                ) {
                    item(key = "search_inputs") {
                        SearchPersonSection(
                            nameQuery = uiState.nameQuery,
                            partQuery = uiState.partQuery,
                            wardQuery = uiState.wardQuery,
                            partError = uiState.partError,
                            wardError = uiState.wardError,
                            selectedLanguage = uiState.selectedLanguage,
                            onNameChange = viewModel::onNameQueryChange,
                            onPartChange = viewModel::onPartQueryChange,
                            onWardChange = viewModel::onWardQueryChange,
                            onClearFilters = viewModel::clearFilters,
                            activeMatchCount = uiState.filteredRecords.size
                        )
                    }

                    searchResultsItems(
                        records = uiState.filteredRecords,
                        isLoading = uiState.isLoading,
                        selectedLanguage = uiState.selectedLanguage,
                        onViewDetails = viewModel::selectPersonForDetails,
                        onViewSlip = viewModel::openSlip,
                        onPrint = { record -> viewModel.printSlip(context, record) },
                        onDownloadPdf = { record -> viewModel.downloadPdf(context, record) },
                        onSharePdf = { record -> viewModel.sharePdf(context, record) },
                        onClearFilters = viewModel::clearFilters
                    )
                }
            }

            "settings" -> {
                Box(modifier = Modifier.padding(innerPadding)) {
                    SettingsScreen(
                        selectedLanguage = uiState.selectedLanguage,
                        totalRecords = uiState.totalRecords,
                        onSelectLanguage = viewModel::setLanguage,
                        onLogout = viewModel::logout
                    )
                }
            }
        }
    }
}
