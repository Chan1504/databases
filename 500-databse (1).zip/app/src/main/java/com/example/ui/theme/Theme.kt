package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CivicNavy60,
    onPrimary = PureWhite,
    primaryContainer = CivicNavy80,
    onPrimaryContainer = CivicNavy20,
    secondary = EmeraldGreen60,
    onSecondary = PureWhite,
    secondaryContainer = EmeraldGreen80,
    onSecondaryContainer = EmeraldGreen20,
    tertiary = AmberGold60,
    onTertiary = PureWhite,
    tertiaryContainer = AmberGold80,
    onTertiaryContainer = AmberGold20,
    background = Slate900,
    onBackground = Slate100,
    surface = Slate800,
    onSurface = Slate100,
    surfaceVariant = Slate700,
    onSurfaceVariant = Slate300,
    outline = Slate500,
    outlineVariant = Slate600
)

private val LightColorScheme = lightColorScheme(
    primary = CivicNavy80,
    onPrimary = PureWhite,
    primaryContainer = CivicNavy10,
    onPrimaryContainer = CivicNavy80,
    secondary = EmeraldGreen60,
    onSecondary = PureWhite,
    secondaryContainer = EmeraldGreen10,
    onSecondaryContainer = EmeraldGreen80,
    tertiary = AmberGold80,
    onTertiary = PureWhite,
    tertiaryContainer = AmberGold10,
    onTertiaryContainer = AmberGold80,
    background = Slate50,
    onBackground = Slate900,
    surface = PureWhite,
    onSurface = Slate900,
    surfaceVariant = Slate100,
    onSurfaceVariant = Slate600,
    outline = Slate300,
    outlineVariant = Slate200
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our civic palette for consistent branding
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
