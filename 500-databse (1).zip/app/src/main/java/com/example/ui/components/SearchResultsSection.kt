package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VoterRecord
import com.example.ui.theme.CivicNavy80
import com.example.ui.theme.EmeraldGreen60
import com.example.util.AppLanguage
import com.example.util.LocaleStrings

/**
 * High-performance virtualized items extension for LazyColumn.
 * Renders only visible voter cards, recycling views for 60/120 FPS scrolling.
 */
fun LazyListScope.searchResultsItems(
    records: List<VoterRecord>,
    isLoading: Boolean,
    selectedLanguage: AppLanguage,
    onViewDetails: (VoterRecord) -> Unit,
    onViewSlip: (VoterRecord) -> Unit,
    onPrint: (VoterRecord) -> Unit,
    onDownloadPdf: (VoterRecord) -> Unit,
    onSharePdf: (VoterRecord) -> Unit,
    onClearFilters: () -> Unit
) {
    item(key = "search_results_header") {
        SearchResultsHeader(
            count = records.size,
            selectedLanguage = selectedLanguage,
            modifier = Modifier.testTag("search_results_section")
        )
    }

    if (isLoading) {
        item(key = "search_results_loading") {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        }
    } else if (records.isEmpty()) {
        item(key = "search_results_empty") {
            EmptySearchState(
                selectedLanguage = selectedLanguage,
                onClearFilters = onClearFilters
            )
        }
    } else {
        items(
            items = records,
            key = { it.srNo },
            contentType = { "voter_card" }
        ) { record ->
            PersonResultCard(
                record = record,
                selectedLanguage = selectedLanguage,
                onViewDetails = { onViewDetails(record) },
                onViewSlip = { onViewSlip(record) },
                onPrint = { onPrint(record) },
                onDownloadPdf = { onDownloadPdf(record) },
                onSharePdf = { onSharePdf(record) }
            )
        }
    }
}

@Composable
fun SearchResultsHeader(
    count: Int,
    selectedLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = LocaleStrings.searchPerson(selectedLanguage),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Text(
                text = LocaleStrings.resultsFound(count, selectedLanguage),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun SearchResultsSection(
    records: List<VoterRecord>,
    isLoading: Boolean,
    selectedLanguage: AppLanguage,
    onViewDetails: (VoterRecord) -> Unit,
    onViewSlip: (VoterRecord) -> Unit,
    onPrint: (VoterRecord) -> Unit,
    onDownloadPdf: (VoterRecord) -> Unit,
    onSharePdf: (VoterRecord) -> Unit,
    onClearFilters: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("search_results_section")
    ) {
        SearchResultsHeader(
            count = records.size,
            selectedLanguage = selectedLanguage
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else if (records.isEmpty()) {
            EmptySearchState(
                selectedLanguage = selectedLanguage,
                onClearFilters = onClearFilters
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                records.forEach { record ->
                    PersonResultCard(
                        record = record,
                        selectedLanguage = selectedLanguage,
                        onViewDetails = { onViewDetails(record) },
                        onViewSlip = { onViewSlip(record) },
                        onPrint = { onPrint(record) },
                        onDownloadPdf = { onDownloadPdf(record) },
                        onSharePdf = { onSharePdf(record) }
                    )
                }
            }
        }
    }
}

@Composable
fun PersonResultCard(
    record: VoterRecord,
    selectedLanguage: AppLanguage,
    onViewDetails: () -> Unit,
    onViewSlip: () -> Unit,
    onPrint: () -> Unit,
    onDownloadPdf: () -> Unit,
    onSharePdf: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("result_card_${record.srNo}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Name and Sr. No.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = record.name.firstOrNull()?.uppercase() ?: "P",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = record.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${LocaleStrings.srNo(selectedLanguage)} #${record.srNo}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Badges for Part No & Ward No
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = CivicNavy80.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "Part ${record.partNo}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = CivicNavy80,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EmeraldGreen60.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "Ward ${record.wardNumber}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldGreen60,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Address
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    text = "${LocaleStrings.address(selectedLanguage)}: ",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = record.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            // Actions Row (Min 48dp touch targets)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // View Details
                OutlinedButton(
                    onClick = onViewDetails,
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("btn_details_${record.srNo}"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = LocaleStrings.viewDetails(selectedLanguage),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Generate / View Slip
                Button(
                    onClick = onViewSlip,
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("btn_view_slip_${record.srNo}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(
                        Icons.Default.AssignmentInd,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = LocaleStrings.generateSlip(selectedLanguage),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptySearchState(
    selectedLanguage: AppLanguage,
    onClearFilters: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_search_state"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.SearchOff,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = LocaleStrings.noResultsFound(selectedLanguage),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Try adjusting name spelling, part number (1–250), or ward number (1–50).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onClearFilters,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(LocaleStrings.clearFilters(selectedLanguage))
            }
        }
    }
}
