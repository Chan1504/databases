package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.util.AppLanguage
import com.example.util.LocaleStrings

@Composable
fun SearchPersonSection(
    nameQuery: String,
    partQuery: String,
    wardQuery: String,
    partError: String?,
    wardError: String?,
    selectedLanguage: AppLanguage,
    onNameChange: (String) -> Unit,
    onPartChange: (String) -> Unit,
    onWardChange: (String) -> Unit,
    onClearFilters: () -> Unit,
    activeMatchCount: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("search_person_section"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: "Search Person" + Clear Filters Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        BoxContentCenter {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = LocaleStrings.searchPerson(selectedLanguage),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                val hasActiveFilters = nameQuery.isNotEmpty() || partQuery.isNotEmpty() || wardQuery.isNotEmpty()
                if (hasActiveFilters) {
                    OutlinedButton(
                        onClick = onClearFilters,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("clear_filters_button"),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Icon(
                            Icons.Default.Clear,
                            contentDescription = "Clear Filters",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = LocaleStrings.clearFilters(selectedLanguage),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 1. Search by Name
            OutlinedTextField(
                value = nameQuery,
                onValueChange = onNameChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("name_search_input"),
                label = { Text(LocaleStrings.searchByName(selectedLanguage)) },
                placeholder = { Text("e.g. Bhavna, Pranav, Miller...") },
                leadingIcon = {
                    Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                },
                trailingIcon = {
                    if (nameQuery.isNotEmpty()) {
                        IconButton(onClick = { onNameChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear name input")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Part No. & Ward Number Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Part No. Input (1-250)
                Column(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = partQuery,
                        onValueChange = onPartChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("part_search_input"),
                        label = { Text(LocaleStrings.searchByPartNo(selectedLanguage)) },
                        placeholder = { Text(LocaleStrings.partNoHint(selectedLanguage)) },
                        leadingIcon = {
                            Icon(Icons.Default.Numbers, contentDescription = null)
                        },
                        trailingIcon = {
                            if (partQuery.isNotEmpty()) {
                                IconButton(onClick = { onPartChange("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear Part No.")
                                }
                            }
                        },
                        isError = partError != null,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp)
                    )
                    AnimatedVisibility(visible = partError != null) {
                        partError?.let { err ->
                            Row(
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(err, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                // Ward Number Input (1-50)
                Column(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = wardQuery,
                        onValueChange = onWardChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ward_search_input"),
                        label = { Text(LocaleStrings.searchByWardNo(selectedLanguage)) },
                        placeholder = { Text(LocaleStrings.wardNoHint(selectedLanguage)) },
                        leadingIcon = {
                            Icon(Icons.Default.Numbers, contentDescription = null)
                        },
                        trailingIcon = {
                            if (wardQuery.isNotEmpty()) {
                                IconButton(onClick = { onWardChange("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear Ward No.")
                                }
                            }
                        },
                        isError = wardError != null,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp)
                    )
                    AnimatedVisibility(visible = wardError != null) {
                        wardError?.let { err ->
                            Row(
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(err, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Active Matches Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = LocaleStrings.resultsFound(activeMatchCount, selectedLanguage),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Name + Part No. + Ward No. Combination Supported",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun BoxContentCenter(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box(
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
