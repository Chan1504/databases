package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.model.VoterRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface VoterDao {

    @Query("SELECT COUNT(*) FROM voter_records")
    suspend fun getCount(): Int

    @Query("SELECT COUNT(DISTINCT partNo) FROM voter_records")
    suspend fun getTotalPartsCount(): Int

    @Query("SELECT COUNT(DISTINCT wardNumber) FROM voter_records")
    suspend fun getTotalWardsCount(): Int

    @Query("SELECT * FROM voter_records ORDER BY srNo ASC")
    fun getAllRecordsFlow(): Flow<List<VoterRecord>>

    @Query("SELECT * FROM voter_records ORDER BY srNo ASC")
    suspend fun getAllRecords(): List<VoterRecord>

    @Query("SELECT * FROM voter_records WHERE srNo = :srNo LIMIT 1")
    suspend fun getRecordBySrNo(srNo: Int): VoterRecord?

    @Query("""
        SELECT * FROM voter_records 
        WHERE (:nameQuery = '' OR LOWER(name) LIKE '%' || LOWER(:nameQuery) || '%')
          AND (:partNo IS NULL OR partNo = :partNo)
          AND (:wardNumber IS NULL OR wardNumber = :wardNumber)
        ORDER BY srNo ASC
    """)
    suspend fun searchRecords(
        nameQuery: String,
        partNo: Int?,
        wardNumber: Int?
    ): List<VoterRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(records: List<VoterRecord>)

    @Query("DELETE FROM voter_records")
    suspend fun deleteAll()
}
