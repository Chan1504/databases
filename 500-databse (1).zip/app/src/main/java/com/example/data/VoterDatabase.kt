package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.VoterRecord

@Database(entities = [VoterRecord::class], version = 2, exportSchema = false)
abstract class VoterDatabase : RoomDatabase() {

    abstract fun voterDao(): VoterDao

    companion object {
        @Volatile
        private var INSTANCE: VoterDatabase? = null

        fun getDatabase(context: Context): VoterDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VoterDatabase::class.java,
                    "voter_records.db"
                )
                    .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
