package com.example.data

import android.content.Context
import com.example.model.VoterRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

class CsvVoterRepository(private val context: Context) {

    private var cachedRecords: List<VoterRecord> = emptyList()

    /**
     * Loads records from the default asset file "voters.csv".
     */
    suspend fun loadDefaultRecords(): List<VoterRecord> = withContext(Dispatchers.IO) {
        if (cachedRecords.isNotEmpty()) {
            return@withContext cachedRecords
        }
        val inputStream = context.assets.open("voters.csv")
        val records = parseCsv(inputStream)
        cachedRecords = records
        records
    }

    /**
     * Loads records dynamically from a custom input stream (e.g. user-imported CSV).
     */
    suspend fun loadFromInputStream(inputStream: InputStream): List<VoterRecord> = withContext(Dispatchers.IO) {
        val records = parseCsv(inputStream)
        cachedRecords = records
        records
    }

    /**
     * Resets the cache and reloads default assets.
     */
    suspend fun resetToDefault(): List<VoterRecord> = withContext(Dispatchers.IO) {
        cachedRecords = emptyList()
        loadDefaultRecords()
    }

    /**
     * Filter records by name, partNo, and wardNumber.
     * Name: case-insensitive partial match
     * Part No: match if parsed int matches or text matches
     * Ward: match if parsed int matches or text matches
     */
    fun filterRecords(
        records: List<VoterRecord>,
        nameQuery: String,
        partQuery: String,
        wardQuery: String
    ): List<VoterRecord> {
        val cleanName = nameQuery.trim().lowercase()
        val partInt = partQuery.trim().toIntOrNull()
        val wardInt = wardQuery.trim().toIntOrNull()

        return records.filter { record ->
            val matchesName = cleanName.isEmpty() || record.name.lowercase().contains(cleanName)
            val matchesPart = when {
                partQuery.isBlank() -> true
                partInt != null -> record.partNo == partInt
                else -> record.partNo.toString().contains(partQuery.trim())
            }
            val matchesWard = when {
                wardQuery.isBlank() -> true
                wardInt != null -> record.wardNumber == wardInt
                else -> record.wardNumber.toString().contains(wardQuery.trim())
            }

            matchesName && matchesPart && matchesWard
        }
    }

    /**
     * Parses CSV lines supporting quoted fields.
     */
    private fun parseCsv(inputStream: InputStream): List<VoterRecord> {
        val records = mutableListOf<VoterRecord>()
        BufferedReader(InputStreamReader(inputStream)).use { reader ->
            var line: String? = reader.readLine() // Read header
            while (reader.readLine().also { line = it } != null) {
                val currentLine = line?.trim() ?: continue
                if (currentLine.isEmpty()) continue

                val tokens = parseCsvLine(currentLine)
                if (tokens.size >= 5) {
                    val srNo = tokens[0].toIntOrNull() ?: continue
                    val name = tokens[1].trim()
                    val address = tokens[2].trim()
                    val partNo = tokens[3].toIntOrNull() ?: continue
                    val wardNo = tokens[4].toIntOrNull() ?: continue

                    records.add(
                        VoterRecord(
                            srNo = srNo,
                            name = name,
                            address = address,
                            partNo = partNo,
                            wardNumber = wardNo
                        )
                    )
                }
            }
        }
        return records
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false

        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '\"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '\"') {
                        sb.append('\"')
                        i++ // Skip escaped quote
                    } else {
                        inQuotes = !inQuotes
                    }
                }
                c == ',' && !inQuotes -> {
                    result.add(sb.toString().trim())
                    sb.setLength(0)
                }
                else -> {
                    sb.append(c)
                }
            }
            i++
        }
        result.add(sb.toString().trim())
        return result
    }
}
