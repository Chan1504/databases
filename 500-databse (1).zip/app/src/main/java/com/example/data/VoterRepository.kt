package com.example.data

import android.content.Context
import com.example.model.VoterRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

/**
 * Repository that ensures Room database is populated on first launch from assets/voters.csv,
 * and performs fast Room SQLite indexed queries for searching.
 */
class VoterRepository(private val context: Context) {

    private val database = VoterDatabase.getDatabase(context)
    private val dao = database.voterDao()
    @Volatile
    private var cachedRecords: List<VoterRecord> = emptyList()

    /**
     * Initializes the database if empty by importing the bundled CSV (500 records).
     * Prevents duplicate imports on subsequent launches.
     */
    suspend fun initializeIfEmpty(): List<VoterRecord> = withContext(Dispatchers.IO) {
        if (cachedRecords.isNotEmpty()) {
            return@withContext cachedRecords
        }
        val count = dao.getCount()
        val records = if (count == 0) {
            val inputStream = context.assets.open("voters.csv")
            val parsed = parseCsv(inputStream)
            if (parsed.isNotEmpty()) {
                dao.insertAll(parsed)
            }
            parsed
        } else {
            dao.getAllRecords()
        }
        cachedRecords = records
        records
    }

    suspend fun getCounts(): Triple<Int, Int, Int> = withContext(Dispatchers.IO) {
        val total = dao.getCount()
        val parts = dao.getTotalPartsCount().takeIf { it > 0 } ?: 250
        val wards = dao.getTotalWardsCount().takeIf { it > 0 } ?: 50
        Triple(total, parts, wards)
    }

    suspend fun getAllRecords(): List<VoterRecord> = withContext(Dispatchers.IO) {
        if (cachedRecords.isNotEmpty()) cachedRecords else {
            val recs = dao.getAllRecords()
            cachedRecords = recs
            recs
        }
    }

    suspend fun searchRecords(
        nameQuery: String,
        partNo: Int?,
        wardNumber: Int?
    ): List<VoterRecord> = withContext(Dispatchers.IO) {
        // High-speed indexed Room SQLite query
        dao.searchRecords(
            nameQuery = nameQuery.trim(),
            partNo = partNo,
            wardNumber = wardNumber
        )
    }

    suspend fun getRecordBySrNo(srNo: Int): VoterRecord? = withContext(Dispatchers.IO) {
        dao.getRecordBySrNo(srNo)
    }

    suspend fun reloadFromAsset(): List<VoterRecord> = withContext(Dispatchers.IO) {
        dao.deleteAll()
        val inputStream = context.assets.open("voters.csv")
        val records = parseCsv(inputStream)
        dao.insertAll(records)
        records
    }

    /**
     * Parses custom or bundled CSV with quoted fields support.
     */
    fun parseCsv(inputStream: InputStream): List<VoterRecord> {
        val records = mutableListOf<VoterRecord>()
        BufferedReader(InputStreamReader(inputStream)).use { reader ->
            var line: String?
            var isFirstLine = true
            while (reader.readLine().also { line = it } != null) {
                val currentLine = line?.trim() ?: continue
                if (currentLine.isEmpty()) continue

                if (isFirstLine) {
                    isFirstLine = false
                    // Skip header if present
                    if (currentLine.lowercase().startsWith("sr.") || currentLine.lowercase().startsWith("sr no")) {
                        continue
                    }
                }

                val tokens = parseCsvLine(currentLine)
                if (tokens.size >= 5) {
                    val srNo = tokens[0].trim().toIntOrNull() ?: continue
                    val name = tokens[1].trim()
                    val address = tokens[2].trim()
                    val partNo = tokens[3].trim().toIntOrNull() ?: 0
                    val wardNo = tokens[4].trim().toIntOrNull() ?: 0

                    records.add(
                        VoterRecord(
                            srNo = srNo,
                            name = name,
                            address = address,
                            partNo = partNo,
                            wardNumber = wardNo
                        )
                    )
                }
            }
        }
        return records
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = java.lang.StringBuilder()
        var inQuotes = false

        for (ch in line.toCharArray()) {
            if (ch == '\"') {
                inQuotes = !inQuotes
            } else if (ch == ',' && !inQuotes) {
                result.add(sb.toString())
                sb.setLength(0)
            } else {
                sb.append(ch)
            }
        }
        result.add(sb.toString())
        return result
    }
}
