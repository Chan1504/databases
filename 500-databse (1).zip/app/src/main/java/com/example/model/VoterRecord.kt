package com.example.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents a fictional voter record from the dataset, persisted in Room.
 * Uses indexed columns for high-performance sub-millisecond SQLite queries.
 */
@Entity(
    tableName = "voter_records",
    indices = [
        Index(value = ["partNo"]),
        Index(value = ["wardNumber"]),
        Index(value = ["name"]),
        Index(value = ["partNo", "wardNumber"])
    ]
)
data class VoterRecord(
    @PrimaryKey
    val srNo: Int,
    val name: String,
    val address: String,
    val partNo: Int,
    val wardNumber: Int
)
