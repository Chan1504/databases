package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.VoterRepository
import com.example.model.VoterRecord
import com.example.util.PdfSlipUtil
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Part & Ward Search", appName)
  }

  @Test
  fun `verify dataset rules 500 records part 1 to 250 twice ward 1 to 50 via Room`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = VoterRepository(context)
    val records = repo.initializeIfEmpty()

    // 1. Total records: exactly 500
    assertEquals(500, records.size)

    // 2. Part No ranges 1..250 and every part appears exactly 2 times
    val partCounts = records.groupingBy { it.partNo }.eachCount()
    assertEquals(250, partCounts.size)
    for (part in 1..250) {
      assertEquals("Part $part must appear exactly 2 times", 2, partCounts[part])
    }

    // 3. Ward Number ranges 1..50
    val wards = records.map { it.wardNumber }.toSet()
    assertEquals(50, wards.size)
    assertTrue(wards.contains(1))
    assertTrue(wards.contains(50))

    // 4. Case-insensitive search
    val firstRecord = records.first()
    val partialNameLower = firstRecord.name.substring(0, 3).lowercase()
    val searchResults = repo.searchRecords(nameQuery = partialNameLower, partNo = null, wardNumber = null)
    assertTrue("Search must find record case-insensitively", searchResults.any { it.srNo == firstRecord.srNo })

    // 5. Part No filter returns exactly 2 records
    val part1Results = repo.searchRecords(nameQuery = "", partNo = 1, wardNumber = null)
    assertEquals(2, part1Results.size)
    assertEquals(1, part1Results[0].partNo)
    assertEquals(1, part1Results[1].partNo)

    // 6. Filename sanitization check
    val sanitizedFileName = PdfSlipUtil.getSanitizedFileName(firstRecord)
    assertTrue(sanitizedFileName.startsWith("Person_Slip_"))
    assertTrue(sanitizedFileName.endsWith(".pdf"))
  }
}
